from django.db import models

class sertifikasi(models.Model):
    sertifikasi = models.CharField(max_length=255)

    def __str__(self):
        return self.sertifikasi

class Peserta (models.Model):
    nim = models.CharField(max_length=10)
    nama = models.CharField(max_length=50)
    sertifikasi = models.ForeignKey(sertifikasi,on_delete=models.SET_NULL,null=True)

    def __str__(self) :
        return self.nim