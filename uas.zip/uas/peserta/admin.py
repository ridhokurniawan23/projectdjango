from django.contrib import admin

from . models import Peserta,sertifikasi

admin.site.register(Peserta)
admin.site.register(sertifikasi)